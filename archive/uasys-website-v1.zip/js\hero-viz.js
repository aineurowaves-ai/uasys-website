(() => {
  const canvas = document.getElementById("heroCanvas");
  if (!canvas) return;

  const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  const DPR = Math.min(window.devicePixelRatio || 1, 2);
  let width = 0;
  let height = 0;
  let visible = true;
  let raf = 0;
  let t0 = performance.now();

  const packets = Array.from({ length: 10 }, (_, i) => ({
    track: i % 4,
    progress: Math.random(),
    speed: 0.08 + Math.random() * 0.12,
  }));

  const codeLines = [
    "sync_rf_channel(band=2.4)",
    "deploy_build(env='prod')",
    "route_signal(gain=0.82)",
    "advise_campaign(roi>1.4)",
    "license.check('active')",
  ];

  function resize() {
    const rect = canvas.getBoundingClientRect();
    width = Math.max(320, Math.floor(rect.width));
    height = Math.max(240, Math.floor(rect.height));
    canvas.width = Math.floor(width * DPR);
    canvas.height = Math.floor(height * DPR);
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
  }

  function drawGrid() {
    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.05)";
    ctx.lineWidth = 1;
    const step = 28;
    for (let x = 0; x <= width; x += step) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y <= height; y += step) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawWaveform(time) {
    const x0 = width * 0.08;
    const x1 = width * 0.92;
    const y = height * 0.28;
    const amp = height * 0.08;

    ctx.save();
    ctx.beginPath();
    for (let i = 0; i <= 120; i++) {
      const p = i / 120;
      const x = x0 + (x1 - x0) * p;
      const yPoint =
        y +
        Math.sin(p * Math.PI * 6 + time * 3.2) * amp * 0.55 +
        Math.sin(p * Math.PI * 14 + time * 5.1) * amp * 0.28 +
        Math.sin(p * Math.PI * 2.2 + time * 1.4) * amp * 0.18;
      if (i === 0) ctx.moveTo(x, yPoint);
      else ctx.lineTo(x, yPoint);
    }
    ctx.strokeStyle = "rgba(58, 212, 208, 0.95)";
    ctx.lineWidth = 2;
    ctx.shadowColor = "rgba(58, 212, 208, 0.45)";
    ctx.shadowBlur = 12;
    ctx.stroke();
    ctx.restore();

    // spectrum bars under waveform
    const bars = 28;
    const barW = (x1 - x0) / bars;
    for (let i = 0; i < bars; i++) {
      const n =
        0.25 +
        0.75 *
          Math.abs(
            Math.sin(time * 2.4 + i * 0.55) * 0.6 + Math.sin(time * 1.1 + i * 0.2) * 0.4
          );
      const h = amp * 1.35 * n;
      const x = x0 + i * barW + 2;
      ctx.fillStyle = `rgba(58, 212, 208, ${0.12 + n * 0.28})`;
      ctx.fillRect(x, y + amp * 1.15, barW - 4, h);
    }
  }

  function drawPcbTraces(time) {
    const paths = [
      [
        [0.08, 0.58],
        [0.22, 0.58],
        [0.28, 0.68],
        [0.45, 0.68],
        [0.52, 0.78],
        [0.78, 0.78],
      ],
      [
        [0.12, 0.88],
        [0.3, 0.88],
        [0.36, 0.74],
        [0.58, 0.74],
        [0.66, 0.62],
        [0.9, 0.62],
      ],
      [
        [0.55, 0.52],
        [0.7, 0.52],
        [0.76, 0.42],
        [0.92, 0.42],
      ],
      [
        [0.08, 0.72],
        [0.18, 0.72],
        [0.18, 0.82],
        [0.42, 0.82],
      ],
    ];

    ctx.save();
    paths.forEach((path, index) => {
      ctx.beginPath();
      path.forEach(([px, py], i) => {
        const x = px * width;
        const y = py * height;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      });
      ctx.strokeStyle = "rgba(255,255,255,0.14)";
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // glowing pulse traveling along path
      const pulse = (time * 0.35 + index * 0.22) % 1;
      const seg = Math.min(path.length - 1.001, pulse * (path.length - 1));
      const i0 = Math.floor(seg);
      const f = seg - i0;
      const [ax, ay] = path[i0];
      const [bx, by] = path[i0 + 1];
      const x = (ax + (bx - ax) * f) * width;
      const y = (ay + (by - ay) * f) * height;

      const grad = ctx.createRadialGradient(x, y, 0, x, y, 16);
      grad.addColorStop(0, "rgba(122, 239, 235, 0.95)");
      grad.addColorStop(1, "rgba(58, 212, 208, 0)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(x, y, 16, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#7aefeb";
      ctx.beginPath();
      ctx.arc(x, y, 2.5, 0, Math.PI * 2);
      ctx.fill();
    });
    ctx.restore();
  }

  function drawCodePanel(time) {
    const panelX = width * 0.58;
    const panelY = height * 0.48;
    const panelW = width * 0.34;
    const panelH = height * 0.38;

    ctx.save();
    ctx.fillStyle = "rgba(8, 10, 14, 0.72)";
    ctx.strokeStyle = "rgba(255,255,255,0.1)";
    ctx.lineWidth = 1;
    ctx.fillRect(panelX, panelY, panelW, panelH);
    ctx.strokeRect(panelX, panelY, panelW, panelH);

    ctx.fillStyle = "rgba(58, 212, 208, 0.8)";
    ctx.font = `500 ${Math.max(10, width * 0.018)}px "JetBrains Mono", monospace`;
    ctx.fillText("build.log", panelX + 12, panelY + 22);

    const lineH = Math.max(16, height * 0.045);
    const offset = Math.floor(time * 0.55) % codeLines.length;
    for (let i = 0; i < 4; i++) {
      const line = codeLines[(offset + i) % codeLines.length];
      const y = panelY + 44 + i * lineH;
      const active = i === 1;
      ctx.fillStyle = active ? "rgba(122, 239, 235, 0.95)" : "rgba(180, 186, 196, 0.55)";
      ctx.fillText(`› ${line}`, panelX + 12, y);
    }

    // blinking caret
    if (Math.floor(time * 2) % 2 === 0) {
      ctx.fillStyle = "rgba(58, 212, 208, 0.9)";
      ctx.fillRect(panelX + 12, panelY + panelH - 18, 8, 2);
    }
    ctx.restore();
  }

  function drawAntenna(time) {
    const x = width * 0.18;
    const baseY = height * 0.52;
    const topY = height * 0.12;

    ctx.save();
    ctx.strokeStyle = "rgba(255,255,255,0.35)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(x, baseY);
    ctx.lineTo(x, topY);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(x - 18, baseY);
    ctx.lineTo(x + 18, baseY);
    ctx.stroke();

    ctx.fillStyle = "#3ad4d0";
    ctx.beginPath();
    ctx.arc(x, topY, 3.5, 0, Math.PI * 2);
    ctx.fill();

    for (let i = 0; i < 3; i++) {
      const age = (time * 0.7 + i / 3) % 1;
      const r = 10 + age * 55;
      ctx.beginPath();
      ctx.arc(x, topY, r, -Math.PI * 0.55, Math.PI * 0.55);
      ctx.strokeStyle = `rgba(58, 212, 208, ${0.45 * (1 - age)})`;
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
    ctx.restore();
  }

  function drawPackets(dt) {
    const tracks = [0.58, 0.68, 0.78, 0.88];
    packets.forEach((p) => {
      p.progress += p.speed * dt;
      if (p.progress > 1) p.progress -= 1;
      const x = width * (0.08 + p.progress * 0.45);
      const y = height * tracks[p.track];
      ctx.fillStyle = "rgba(122, 239, 235, 0.9)";
      ctx.fillRect(x, y - 2, 10, 4);
    });
  }

  function frame(now) {
    raf = requestAnimationFrame(frame);
    if (!visible) return;

    const time = (now - t0) / 1000;
    const dt = Math.min(0.05, 1 / 60);

    ctx.clearRect(0, 0, width, height);
    drawGrid();
    drawWaveform(time);
    drawAntenna(time);
    drawPcbTraces(time);
    if (!reduceMotion) drawPackets(dt);
    drawCodePanel(time);
  }

  resize();
  window.addEventListener("resize", resize);

  const stage = canvas.closest(".hero-stage");
  if ("IntersectionObserver" in window && stage) {
    const io = new IntersectionObserver(
      ([entry]) => {
        visible = entry.isIntersecting;
      },
      { threshold: 0.05 }
    );
    io.observe(stage);
  }

  if (reduceMotion) {
    // single static frame
    width = canvas.clientWidth || 720;
    height = canvas.clientHeight || 560;
    resize();
    drawGrid();
    drawWaveform(0.8);
    drawAntenna(0.8);
    drawPcbTraces(0.8);
    drawCodePanel(0.8);
  } else {
    raf = requestAnimationFrame(frame);
  }

  window.addEventListener("beforeunload", () => cancelAnimationFrame(raf));
})();
